install.packages(c("tidyverse", "eurostat", "broom",
                   "fixest", "here", "quarto"))
# Run once per computer; packages stay installed.
library(tidyverse)
library(eurostat)

dirs <- c("R", "data/raw", "data/processed", "figures",
          "results", "report","plots")
invisible(lapply(dirs, dir.create, recursive = TRUE,
                 showWarnings = FALSE))

#DOWNLOADING REAL DATA FROM EUROSTAT----

library(eurostat)
library(readr)
library(dplyr)
main <- get_eurostat("tespm140", time_format = "num")
by_household <- get_eurostat("ilc_lvho07e",
                             time_format = "num")
names(main)
glimpse(main)
unique(main$geo)
summary(main$values)


write_csv(main, "data/raw/tespm140.csv")
write_csv(by_household, "data/raw/ilc_lvho07e.csv")














#CLEANING THE COUNTRY-YEAR DATA-----

library(tidyverse)

raw <- read_csv("data/raw/tespm140.csv",
                show_col_types = FALSE)
eu27 <- c("AT","BE","BG","HR","CY","CZ","DK","EE",
          "FI","FR","DE","EL","HU","IE","IT","LV",
          "LT","LU","MT","NL","PL","PT","RO","SK",
          "SI","ES","SE")


housing <- raw %>%
  dplyr::filter(
    geo %in% eu27,
    as.integer(TIME_PERIOD) >= 2014,
    as.integer(TIME_PERIOD) <= 2024
  ) %>%
  dplyr::transmute(
    country = geo,
    year = as.integer(TIME_PERIOD),
    overburden_pct = as.numeric(values)
  ) %>%
  dplyr::arrange(country, year)

View(housing)


stopifnot(nrow(housing) > 0)
stopifnot(!anyDuplicated(housing[c("country", "year")]))
summary(housing$overburden_pct)
colSums(is.na(housing))

write_csv(housing, "data/processed/housing_clean.csv")

stopifnot(all(is.na(housing$overburden_pct) |
                dplyr::between(housing$overburden_pct, 0, 100)))
housing %>% count(country) %>% print(n = 27)


#EXPLORATORY DATA ANALYSIS----

library(tidyverse)
housing <- read_csv("data/processed/housing_clean.csv",
                    show_col_types = FALSE)
                      

stats <- housing %>%
  group_by(year) %>%
  summarise(n = sum(!is.na(overburden_pct)),
            mean_pct = mean(overburden_pct, na.rm = TRUE),
            median_pct = median(overburden_pct, na.rm = TRUE),
            sd_pct = sd(overburden_pct,  na.rm = TRUE),
            .groups = "drop")
write_csv(stats, "results/yearly_summary.csv")
print(stats)

###FIGURES -> FIGURE1[COUNTRY RANKING FOR 2024]

p1 <- housing %>%
  filter(year == 2024, !is.na(overburden_pct)) %>%
  ggplot(aes(x = reorder(country, overburden_pct),
             y = overburden_pct)) +
  geom_col(fill = "#19798a") + coord_flip() +
  labs(title = "Housing cost overburden in 2024",
       x = "EU country", y = "Population (%)") +
  theme_minimal()
ggsave("figures/01_country_ranking.png", p1,
       width = 8, height = 7, dpi = 180)



###FIGURES -> FIGURE 02 [TREND FOR SELECTED COUNTRIES]

p2 <- housing %>%
  filter(country %in% c("IT", "DE", "AT", "FR", "ES")) %>%
  ggplot(aes(year, overburden_pct, color = country)) +
  geom_line(linewidth = 0.9, na.rm = TRUE) +
  geom_point(size = 1.4, na.rm = TRUE) +
  labs(title = "Selected EU countries, 2014-2024",
       x = "Year", y = "Population (%)") +
  theme_minimal()
ggsave("figures/02_selected_trends.png", p2,
       width = 8, height = 4.7, dpi = 180)


###FIGURES -> EU-27 HEATMAP

p3 <- housing %>%
  ggplot(aes(
    x = year,
    y = country,
    fill = overburden_pct
  )) +
  geom_tile(color = "white", linewidth = 0.2) +
  scale_fill_viridis_c(
    name = "Population (%)",
    option = "C"
  ) +
  scale_x_continuous(
    breaks = 2014:2024
  ) +
  labs(
    title = "Housing cost overburden across EU countries",
    subtitle = "Country-level rates, 2014-2024",
    x = "Year",
    y = "EU country"
  ) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(
      angle = 45,
      hjust = 1
    )
  )

ggsave(
  "figures/03_country_heatmap.png",
  p3,
  width = 9,
  height = 8,
  dpi = 180
)


#FIGURES -> FIGURE4[ YEARLY COUNTRY-AVG RATE]

yearly_average <- housing %>%
  group_by(year) %>%
  summarise(
    average_overburden_pct = mean(
      overburden_pct,
      na.rm = TRUE
    ),
    .groups = "drop"
  )

p4 <- yearly_average %>%
  ggplot(aes(
    x = year,
    y = average_overburden_pct
  )) +
  geom_line(
    color = "#19798a",
    linewidth = 1
  ) +
  geom_point(
    color = "#19798a",
    size = 2
  ) +
  scale_x_continuous(
    breaks = 2014:2024
  ) +
  labs(
    title = "Average housing cost overburden rate",
    subtitle = paste(
      "Unweighted average of national rates,",
      "not the EU population-wide rate"
    ),
    x = "Year",
    y = "Average population (%)"
  ) +
  theme_minimal()

ggsave(
  "figures/04_yearly_country_average.png",
  p4,
  width = 8,
  height = 4.7,
  dpi = 180
)
                      
#2ND RESEARCH QUESTION[ HOUSEHOLD COMPOSITION]----

library(tidyverse)
hh <- read_csv("data/raw/ilc_lvho07e.csv",
               show_col_types = FALSE)
names(hh)
unique(hh$hhcomp) ### inspect actual composition codes
unique(hh$unit)


hh_2024 <- hh %>%
  filter(geo %in% c("IT", "DE", "AT", "FR", "ES"),
         TIME_PERIOD ==2024, !is.na(values))

#use the printed household codes to choose 2-3
#meaningful categories and create a groupped bar plot.
print(hh_2024, n = 30)


#STATISTICAL REGRESSION----



###we will start with ordinary linear regression to understand coefficients, then move to fixed effects.

##MODEL 01 [SIMPLE DESCRIPTIVE TIME TREND]

library(tidyverse)
library(broom)
housing <- read_csv("data/processed/housing_clean.csv",
                    show_col_types = FALSE)
m1 <- lm(overburden_pct ~ year, data = housing)
summary(m1)
tidy(m1, conf.int = TRUE)
plot(m1) #inspect residuals diagnostics

#SAVING THE PLOTS TO REVIEW IN MODEL

png("plots/01_residuals_vs_fitted.png",
    width = 1600, height = 1200, res = 180)
plot(m1, which = 1)
dev.off()

png("plots/02_qq_residuals.png",
    width = 1600, height = 1200, res = 180)
plot(m1, which = 2)
dev.off()

png("plots/03_scale_location.png",
    width = 1600, height = 1200, res = 180)
plot(m1, which = 3)
dev.off()

png("plots/04_residuals_vs_leverage.png",
    width = 1600, height = 1200, res = 180)
plot(m1, which = 5)
dev.off()



##MODEL 02 [FIXED EFFECT PANEL REGRESSION]
library(fixest)
m2 <- feols(overburden_pct ~ year | country, 
            data = housing, vcov = ~country)
summary(m2)

#optional year_fixed-effects model for studying


#country differences by year (without year slope):
##MODEL 03: [DESCRIPTIVE TWO-WAY FIXED EFFECT SPECIFICATION]


m3 <- feols(overburden_pct ~ 1| country + year, 
            data = housing, vcov = ~country)
summary(m3)




#OPTIONAL FORECASTING----

library(tidyverse)
housing <- read_csv("data/processed/housing_clean.csv",
                    show_col_types = FALSE)

#one-step baseline predict 2024 using 2023 value

baseline <- housing %>%
  filter( year %in% c(2023,2024)) %>%
  pivot_wider(names_from = year,
              values_from = overburden_pct,
              names_prefix = "y") %>%
  filter(!is.na(y2023), !is.na(y2024)) %>%
  mutate(error = y2024 - y2023)
           

mae <- mean(abs(baseline$error))
rmse <- sqrt(mean(baseline$error^2))
print(c(MAE = mae, RMSE = rmse))





