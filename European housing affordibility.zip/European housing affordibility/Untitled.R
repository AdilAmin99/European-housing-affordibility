install.packages(c("tidyverse", "eurostat", "broom",
                   "fixest", "here", "quarto"))
# Run once per computer; packages stay installed.
library(tidyverse)
library(eurostat)

dirs <- c("R", "data/raw", "data/processed", "figures",
          "results", "report")
invisible(lapply(dirs, dir.create, recursive = TRUE,
                 showWarnings = FALSE))


#DOWNLOADING NECESSARY DATA----

library(eurostat)
library(readr)
library(dplyr)
main <- get_eurostat("tespm140", time_format = "num")
by_household <- get_eurostat("ilc_lvho07e",
                             time_format = "num")

names(main)
glimpse(main)
unique(main$geo)
summary(main$values)
write_csv(main, "data/raw/tespm140.csv")
write_csv(by_household, "data/raw/ilc_lvho07e.csv")